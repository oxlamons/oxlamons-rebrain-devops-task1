
# <br/> Nginx configuration file <br>

## <br/> This repository contains the default nginx config file
===============================================================
###  Course from Rebraine<br>

#### <br/> Description <br>
Nginx — веб-сервер и почтовый прокси-сервер, работающий на Unix-подобных операционных системах. Начиная с версии 0.7.52 появилась экспериментальная бинарная сборка под Microsoft Windows. Игорь Сысоев начал разработку в 2002 году. Осенью 2004 года вышел первый публично доступный релиз.

Home page [nginx](https://nginx.org/)
--------------------------------------------------------------
#### <br/>Contact
>>email oxlamons@gmail.com <br/>
telegram [@Dude_20](https://web.telegram)
